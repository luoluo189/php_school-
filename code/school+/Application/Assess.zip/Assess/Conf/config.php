<?php
return array(
	//'配置项'=>'配置值'
//    'LAYOUT_ON'              => , // 是否启用布局
);